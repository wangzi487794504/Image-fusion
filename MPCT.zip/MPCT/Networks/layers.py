
import torch
import torch.nn as nn

from torch.nn import functional as F
import numpy as np  
#自己重写了一个2d的卷积
class Conv2d(nn.Conv2d):
    #dilation是否采用空洞卷积,1为不采用
    #groups决定了是否采用分组卷积，即分开一定的通道数
    #padding默认0
    #偏置默认有
    def __init__(self, in_channels, out_channels, kernel_size, stride=1,
                 padding=0, dilation=1, groups=1, bias=True):
        super(Conv2d, self).__init__(in_channels, out_channels, kernel_size, stride,
                 padding, dilation, groups, bias)

        if kernel_size == 1:    #1*1卷积
            self.ind = True
        else:                   #>=2卷积，卷积自带池化
            self.ind = False            
            self.oc = out_channels#输出通道
            self.ks = kernel_size#卷积大小

            ws = kernel_size
            self.avg_pool = nn.AdaptiveAvgPool2d((ws,ws))#自适应池化，ws为输出维度3*3

            self.num_lat = int((kernel_size * kernel_size) / 2 + 1)#如果是3*3，则3*3/2+1=5

            self.ce = nn.Linear(ws*ws, self.num_lat, False) #线性层  ，input=9,output=5
            self.ce_bn = nn.BatchNorm1d(in_channels)
            self.ci_bn2 = nn.BatchNorm1d(in_channels)

            self.act = nn.ReLU(inplace=True)
            

            if in_channels // 16:  #取整除，判断输入的通道数是否是16的倍数
                self.g = 16
            else:
                self.g = in_channels

            self.ci = nn.Linear(self.g, out_channels // (in_channels // self.g), bias=False)#g=2,out=16//(2//2)=16
            self.ci_bn = nn.BatchNorm1d(out_channels)

            self.gd = nn.Linear(self.num_lat, kernel_size * kernel_size, False)#in=5,out=9
            self.gd2 = nn.Linear(self.num_lat, kernel_size * kernel_size, False)#in=5,out=9

            self.unfold = nn.Unfold(kernel_size, dilation, padding, stride)#3，1，1，1

            self.sig = nn.Sigmoid()
    def forward(self, x):

        if self.ind:  #如果是1*1，直接调用pytorch的
            return F.conv2d(x, self.weight, self.bias, self.stride,
                        self.padding, self.dilation, self.groups)
        else:
            b, c, h, w = x.size()
            weight = self.weight

            gl = self.avg_pool(x).view(b,c,-1)#池化就是reshape

            out = self.ce(gl)#线性

            ce2 = out
            out = self.ce_bn(out)#标准化
            out = self.act(out)#relu激活

            out = self.gd(out)#线性

            if self.g >3:#通道数>3
                 #标准加激活线性
                oc = self.ci(self.act(self.ci_bn2(ce2).\
                                      view(b, c//self.g, self.g, -1).transpose(2,3))).transpose(2,3).contiguous()
            else:

                oc = self.ci(self.act(self.ci_bn2(ce2).transpose(2,1))).transpose(2,1).contiguous() 
            oc = oc.view(b,self.oc,-1) 
            oc = self.ci_bn(oc)
            oc = self.act(oc)

            oc = self.gd2(oc)   

            out = self.sig(out.view(b, 1, c, self.ks, self.ks) + oc.view(b, self.oc, 1, self.ks, self.ks))

            x_un = self.unfold(x)
            b, _, l = x_un.size()

            out = (out * weight.unsqueeze(0)).view(b, self.oc, -1)

            return torch.matmul(out, x_un).view(b, self.oc, int(np.sqrt(l)), int(np.sqrt(l)))
            
