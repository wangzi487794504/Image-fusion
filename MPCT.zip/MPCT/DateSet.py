import os
from glob import glob
import torch
import torchvision.transforms as transforms
from PIL import Image
import numpy as np
from torch.utils.data import DataLoader, Dataset
from color import RGB_YUV as yuv
##数据集
class GetDataset(Dataset):
    def __init__(self, imageFolderDataset, transform=None):
        self.imageFolderDataset = imageFolderDataset
        self.transform = transform
        self.file_a = glob(os.path.join(imageFolderDataset, 'SPECT', '*.*'))
        self.file_b = glob(os.path.join(imageFolderDataset, 'MRI', '*.*'))
        self.yuv=yuv()

    def __getitem__(self, index,transformer=None):

    #图片路径
        ir = Image.open(self.file_a[index])#spect

        vi = Image.open(self.file_b[index])
    #图篇转换
        ir = ir.convert('RGB')#spect
        # print("PIL_ir三色彩,", ir.size)
        ir=np.array(ir)
        # print("numpy_ir三色彩,",ir.shape)#(256, 256, 3)
        ir, Cr, Cb,ycbcr = self.yuv.rgb_to_ycbcr(im_rgb=ir)  # spect
        vi = vi.convert('L')
    #转成pytorch向量
        if self.transform is not None:
            tran = transforms.ToTensor()
            #对图片进行处理
            ir=tran(ir)
            vi= tran(vi)
            Cr=tran(Cr)
            Cb=tran(Cb)
            # print("vi=", vi.shape)
            # print("ir=", ir.shape)

            #进行拼接
            input = torch.cat((ir, vi), -3)#[2, 256, 256
            # print("dataset_input=",input.shape)
            #返回拼接的以及tensor
            return input, ir,vi,Cr,Cb,ycbcr

    def __len__(self):
        return len(self.file_b)
