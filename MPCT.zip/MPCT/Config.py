import argparse


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--name', default='test', help='model name: (default: arch+timestamp)')
    parser.add_argument('--epochs', default=90, type=int)
    parser.add_argument('--batch_size', default=6, type=int)
    parser.add_argument('--lr', '--learning-rate', default=1e-3, type=float)
    parser.add_argument('--weight', default=[1, 1, 1, 2.5], type=float, nargs='+')
    parser.add_argument('--betas', default=(0.9, 0.999), type=float, nargs=2)
    parser.add_argument('--eps', default=1e-8, type=float)
    parser.add_argument('--alpha', default=300, type=int,
                        help='number of new channel increases per depth (default: 300)')
    args = parser.parse_args()
    return args